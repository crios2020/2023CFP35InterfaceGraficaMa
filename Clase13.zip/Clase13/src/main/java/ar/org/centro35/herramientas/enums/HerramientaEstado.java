package ar.org.centro35.herramientas.enums;

public enum HerramientaEstado {
    BUENA,
    REGULAR,
    MALA,
    FUERA_DE_USO
}
