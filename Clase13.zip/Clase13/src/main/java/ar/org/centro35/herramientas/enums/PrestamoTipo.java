package ar.org.centro35.herramientas.enums;

public enum PrestamoTipo {
    h24,
    h48,
    h72,
    h96
}
