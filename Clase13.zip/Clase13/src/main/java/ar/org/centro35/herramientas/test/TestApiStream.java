package ar.org.centro35.herramientas.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TestApiStream {
    public static void main(String[] args) {
        List<Persona>lista=new ArrayList();
        lista.add(new Persona("Laura", "Gomez", 26));
        lista.add(new Persona("Cristian", "Molina", 65));
        lista.add(new Persona("Javier", "Lorenzo", 36));
        lista.add(new Persona("Melina", "Morano", 39));
        lista.add(new Persona("Eliana", "Doreti", 29));
        lista.add(new Persona("Abel", "Herrera", 46));
        lista.add(new Persona("Laura", "Perez", 26));
        lista.add(new Persona("Lautaro", "Perez", 26));
        lista.add(new Persona("laura", "Perez", 26));
        lista.add(new Persona("LAURA", "Perez", 26));
        lista.add(new Persona("Leonardo", "Perez", 26));
        lista.add(new Persona("Lucas", "Perez", 26));
        lista.add(new Persona("Ana", "Perez", 26));
        lista.add(new Persona("Mariela", "Perez", 26));
        lista.add(new Persona("Omar", "Perez", 26));
        lista.add(new Persona("Carlos", "Perez", 26));
        lista.add(new Persona("Marta", "Perez", 26));
        lista.add(new Persona("Barni", "Gomez", 56));
        lista.add(new Persona("Monica", "Tucci", 26));
        lista.add(new Persona("Mirta", "Abate", 26));

        //select * from lista
        System.out.println("****************************************************");
        //lista.forEach(System.out::println);
        lista.stream().forEach(System.out::println);

        //select * from lista where nombre='Laura';
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().equals("Laura"))
                .forEach(System.out::println);
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("Laura"))
                .forEach(System.out::println);
        
        //select * from lista where nombre like 'l%'
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("l"))
                .forEach(System.out::println);

        //select * from lista where nombre like 'lau%'
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("lau"))
                .forEach(System.out::println);        
        

        //select * from lista where nombre like '%a'
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);

        //select * from lista where nombre like '%ar%'
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);
            
        
        //select * from lista where nombre='laura' or nombre='marta'
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("laura")
                         ||p.getNombre().equalsIgnoreCase("marta"))
                .forEach(System.out::println);
        
        //select * from lista where nombre='laura' or apellido='gomez'
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("laura")
                         ||p.getApellido().equalsIgnoreCase("gomez"))
                .forEach(System.out::println);


        //select * from lista where nombre='laura' and apellido='gomez'
        System.out.println("****************************************************");
        // lista
        //         .stream()
        //         .filter(p->p.getNombre().equalsIgnoreCase("laura")
        //                  &&p.getApellido().equalsIgnoreCase("gomez"))
        //         .forEach(System.out::println);

        lista
                    .stream()
                    .filter(p->p.getNombre().equalsIgnoreCase("laura"))
                    .filter(p->p.getApellido().equalsIgnoreCase("gomez"))
                    .forEach(System.out::println);
        
        //select * from lista where edad<=30
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getEdad()<=30)
                .forEach(System.out::println);
    
        //select * from lista where edad between 30 and 40
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getEdad()>=30)
                .filter(p->p.getEdad()<=40)
                .forEach(System.out::println);
        
        //select * from lista where edad not between 30 and 40
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getEdad()<30 || p.getEdad()>40)
                .forEach(System.out::println);
        
        //select * from lista order by apellido
        System.out.println("****************************************************");
        lista
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);

        //select * from lista order by apellido desc
        System.out.println("****************************************************");
        lista
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido).reversed())
                .forEach(System.out::println);
        
        //select * from lista order by apellido, nombre
        System.out.println("****************************************************");
        // lista
        //         .stream()
        //         .sorted(Comparator.comparing(Persona::getApellido)
        //                         .thenComparing(Persona::getNombre))
        //         .forEach(System.out::println);
        lista
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);

        //select * from lista where edad<=30 order by apellido, nombre
        System.out.println("****************************************************");
        lista
                .stream()
                .filter(p->p.getEdad()<=30)
                .sorted(Comparator.comparing(Persona::getNombre))
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);

        //select count(*) from personas
        System.out.println("****************************************************");
        long cantidad=lista.stream().count();
        System.out.println(cantidad);      
        
        //select count(*) from personas where nombre='laura'
        System.out.println("****************************************************");
        cantidad=lista.stream().filter(p->p.getNombre().equalsIgnoreCase("laura")).count();
        System.out.println(cantidad);


        //TODO Subconsultas
        

    }
}
