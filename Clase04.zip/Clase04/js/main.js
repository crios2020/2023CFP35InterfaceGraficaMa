addEventListener('load',inicio,false);

function inicio()
{
  document.getElementById('edad').addEventListener('change',cambiarEdad,false);
}

function cambiarEdad()
{    
  document.getElementById('visorEdad').innerHTML=document.getElementById('edad').value;
}