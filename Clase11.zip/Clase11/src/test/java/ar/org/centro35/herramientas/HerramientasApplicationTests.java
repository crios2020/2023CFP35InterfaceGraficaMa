package ar.org.centro35.herramientas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HerramientasApplicationTests {

	@Test
	void contextLoads() {
	}

}
