package ar.org.centro35.herramientas.enums;

public enum SocioEstado {
    ACTIVO,
    NO_ACTIVO
}
